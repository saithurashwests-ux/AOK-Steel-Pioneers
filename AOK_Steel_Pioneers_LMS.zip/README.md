# AOK Steel Pioneers — LMS Starter

A small responsive learning website built with HTML, CSS, JavaScript and Firebase. It includes Google sign-in, an administrator-only board, course/lesson editing, profile editing, and a simple lesson-completion record.

## Important
This is a starter project, not yet connected to your Firebase account. I cannot create or manage a cloud database inside your Google account without you creating the Firebase project and applying the settings. The app code and database structure/rules are provided here.

## 1. Configure Firebase
1. Open https://console.firebase.google.com/ and sign in with the Google account you want to use.
2. Create a project named `AOK Steel Pioneers` (or another project ID).
3. In Project settings, add a Web App (`</>` icon) and copy the Firebase config.
4. Open `firebase-config.js` and replace all `PASTE_...` values.
5. Set `adminEmail` to your exact Google email address.
6. In Firebase Authentication → Sign-in method, enable **Google**.
7. In Authentication → Settings → Authorized domains, add your deployed domain if needed.
8. In Firestore Database, create a database (start in production mode).
9. Open the Rules tab and paste `firestore.rules`. Replace `YOUR_GOOGLE_EMAIL@gmail.com` with the same admin email.
10. In Storage → Get started only if you later want to upload files directly. If you use Storage, replace the email in `storage.rules` and publish those rules.

## 2. Run the website locally
Because this app uses JavaScript modules, open it through a local web server, not by double-clicking `index.html`.
- If you have Python installed, open a terminal in this folder and run: `python -m http.server 8000`
- Open `http://localhost:8000` in your browser.
- You can also use VS Code's Live Server extension.

## 3. Put it on the Internet
For a simple static deployment, use Firebase Hosting:
1. Install Node.js on a computer.
2. Install Firebase CLI: `npm install -g firebase-tools`
3. Run `firebase login`
4. In this folder run `firebase init hosting`; choose your existing Firebase project and set the public directory to this folder (or copy the files to a clean `public` folder).
5. Run `firebase deploy`.
6. If you deploy to a different domain, add it to Firebase Authentication → Authorized domains.

Other static hosting providers can work too, but keep Firestore rules published and never put private service-account keys in frontend files.

## 4. Current features
- Google sign-in / sign-out
- Admin board shown only when the signed-in Google email matches `adminEmail`
- Create, edit, publish/unpublish, and delete courses
- Add/edit/delete lessons with text and image/video/PDF URLs
- YouTube video embed support
- Profile display name and bio editing
- Basic user overview and lesson-completion records
- Responsive mobile and desktop layout

## 5. Current limitations / next improvements
- This first version uses URLs for course images, videos, and PDFs. It does not yet upload files from the computer directly.
- Quiz creation/marking, assignment submission, certificates, and detailed progress reports are not implemented yet.
- User accounts are created by Google sign-in. This starter does not provide an admin invitation/approval flow.
- Admin email checks in the UI are only for hiding the menu; actual security depends on the Firestore/Storage rules. Replace the placeholder admin email in both rules files before deployment.
- If a learner should not be allowed to register, disable any other sign-in providers and consider adding an approved-user allowlist in the database rules.
- Never use test-mode Firestore rules for a live website.

## Data structure
- `courses`: title, description, category, imageUrl, published, timestamps
- `lessons`: courseId, title, text, imageUrl, videoUrl, pdfUrl, published, order
- `users`: basic Google account details and last seen
- `profiles`: user-edited display name and bio
- `progress`: lesson completion records

## Troubleshooting
- “Firebase setup needed”: `firebase-config.js` still contains placeholder values.
- Google login fails: enable Google provider and add your domain to Authorized domains.
- Cannot save courses: check that your email in `firebase-config.js` and `firestore.rules` is exactly the same, and publish the rules.
- Cannot load courses: create Firestore Database and publish the provided rules.
